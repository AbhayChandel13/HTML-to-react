import React from 'react'

const Read = () => {
  return (
    <>
    <main id="main" className="Main">
    <div className="pagetitle">
          <h1>Read Data Page</h1>
          <nav>
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <a href="/">Home</a>
              </li>
              <li className="breadcrumb-item">New Menu</li>
              <li className="breadcrumb-item active">Read</li>
            </ol>
          </nav>
        </div>
        <h1> You Are On The Read Me Page</h1>
     
    </main>
    </>
  )
}

export default Read
